package top.soy_bottle.pso.db.airportdb

object FlightLogTable {

}