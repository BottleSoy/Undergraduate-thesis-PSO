package top.soy_bottle.pso

enum class TiDBForcePriority {
	NO_PRIORITY,
	LOW_PRIORITY,
	DELAYED,
	HIGH_PRIORITY
}